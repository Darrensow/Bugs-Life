package me.xdrop.diffutils.structs;

public enum EditType {

    DELETE,
    EQUAL,
    INSERT,
    REPLACE,
    KEEP

}
